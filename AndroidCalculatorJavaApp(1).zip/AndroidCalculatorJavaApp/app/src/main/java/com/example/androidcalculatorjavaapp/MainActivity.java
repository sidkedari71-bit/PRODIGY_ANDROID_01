package com.example.androidcalculatorjavaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView tvResult;
    private Double firstNumber = null;
    private String operator = null;
    private boolean isNewOp = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvResult = findViewById(R.id.tvResult);

        Button btn0 = findViewById(R.id.btn0);
        Button btn1 = findViewById(R.id.btn1);
        Button btn2 = findViewById(R.id.btn2);
        Button btn3 = findViewById(R.id.btn3);
        Button btn4 = findViewById(R.id.btn4);
        Button btn5 = findViewById(R.id.btn5);
        Button btn6 = findViewById(R.id.btn6);
        Button btn7 = findViewById(R.id.btn7);
        Button btn8 = findViewById(R.id.btn8);
        Button btn9 = findViewById(R.id.btn9);
        Button btnDot = findViewById(R.id.btnDot);

        Button btnAdd = findViewById(R.id.btnAdd);
        Button btnSub = findViewById(R.id.btnSub);
        Button btnMul = findViewById(R.id.btnMul);
        Button btnDiv = findViewById(R.id.btnDiv);
        Button btnEqual = findViewById(R.id.btnEqual);
        Button btnClear = findViewById(R.id.btnClear);

        View.OnClickListener numberClickListener = v -> {
            Button b = (Button) v;
            String text = b.getText().toString();
            String current = tvResult.getText().toString();

            if (isNewOp || current.equals("0")) {
                tvResult.setText(text);
                isNewOp = false;
            } else {
                tvResult.setText(current + text);
            }
        };

        btn0.setOnClickListener(numberClickListener);
        btn1.setOnClickListener(numberClickListener);
        btn2.setOnClickListener(numberClickListener);
        btn3.setOnClickListener(numberClickListener);
        btn4.setOnClickListener(numberClickListener);
        btn5.setOnClickListener(numberClickListener);
        btn6.setOnClickListener(numberClickListener);
        btn7.setOnClickListener(numberClickListener);
        btn8.setOnClickListener(numberClickListener);
        btn9.setOnClickListener(numberClickListener);

        btnDot.setOnClickListener(v -> {
            String current = tvResult.getText().toString();
            if (!current.contains(".")) {
                if (isNewOp || current.equals("0")) {
                    tvResult.setText("0.");
                    isNewOp = false;
                } else {
                    tvResult.setText(current + ".");
                }
            }
        });

        View.OnClickListener opClickListener = v -> {
            Button b = (Button) v;
            String op = b.getText().toString();
            String current = tvResult.getText().toString();

            try {
                firstNumber = Double.parseDouble(current);
                operator = op;
                isNewOp = true;
            } catch (NumberFormatException e) {
                firstNumber = null;
                operator = null;
            }
        };

        btnAdd.setOnClickListener(opClickListener);
        btnSub.setOnClickListener(opClickListener);
        btnMul.setOnClickListener(opClickListener);
        btnDiv.setOnClickListener(opClickListener);

        btnEqual.setOnClickListener(v -> {
            if (firstNumber == null || operator == null) return;

            String current = tvResult.getText().toString();
            Double secondNumber;
            try {
                secondNumber = Double.parseDouble(current);
            } catch (NumberFormatException e) {
                return;
            }

            Double result = null;

            switch (operator) {
                case "+":
                    result = firstNumber + secondNumber;
                    break;
                case "-":
                    result = firstNumber - secondNumber;
                    break;
                case "*":
                    result = firstNumber * secondNumber;
                    break;
                case "/":
                    if (secondNumber == 0) {
                        tvResult.setText("Error");
                        isNewOp = true;
                        return;
                    } else {
                        result = firstNumber / secondNumber;
                    }
                    break;
            }

            if (result != null) {
                if (result % 1 == 0) {
                    tvResult.setText(String.valueOf(result.intValue()));
                } else {
                    tvResult.setText(String.valueOf(result));
                }
            }
            isNewOp = true;
        });

        btnClear.setOnClickListener(v -> {
            tvResult.setText("0");
            firstNumber = null;
            operator = null;
            isNewOp = true;
        });
    }
}
